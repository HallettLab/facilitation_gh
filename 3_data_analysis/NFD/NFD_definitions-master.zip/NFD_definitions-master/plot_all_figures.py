"""
@author: J.W.Spaak
Plot all figures from the manuscript
"""

import plot_Figure1
import plot_Figure2
import plot_Figure3
import plot_Figure4
import plot_Figure5

import plot_FigureA2
import plot_FigureA3
